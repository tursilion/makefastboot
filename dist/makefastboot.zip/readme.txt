This is a new version of 'makefastboot' with a new header that still boots fast, but also checksums the cart and lets you edit the checksum without re-encrypting. The resulting cart should boot in roughly 1 second instead of 5 seconds, but still go red for bad contacts. :)

It also includes the original jagcrypt for carts (with a small hack of my own), since that tool was hard to find.

Source is all on github: https://github.com/tursilion/makefastboot

No docs offered for jagcrypt, for for makefastboot:

Start with a working cartridge, including the header of your choice (either a formal one, or TypeAB. It doesn't have to boot, but it has to be present.)

Run "makefastboot <cartridge file>" - ie: makefastboot "Alien vs Predator.jag"

If the program doesn't think there's a header (some ROMs do not), it will ask "add new header?" If you do this, it will add a dummy 8k header with assumed defaults. If it doesn't work you're on your own, this feature relies on you knowing.

-Once past the header check, it will ask:

Set cartridge width:
  1: 8-bit
  2:16-bit
  3:32-bit (Default)
  
The width depends on the cart you will be burning it to. Official Jaguar carts were all 32-bit. Pretty much everything runs fine at 16-bit. I've never tried 8-bit, but in theory it may work for most, with increased load times.

Next it will ask:

Set cartridge speed:
  1:10 clocks (Default)
  2: 8 clocks
  3: 6 clocks
  4: 5 clocks
  
Original 32-bit carts ran at 10 clocks and unless you know better, that's what you should select. To get the same performance with 16-bit, you can try 5 clocks, but you need to make sure your EPROMs are fast enough. For 10 clocks you need about 300-350ns ROMs. For 5 clocks you need half that - so 150-175ns. Select the slowest you can live with (and note that it's possible for a game to suffer if on a slower performing bus. But if you need a benchmark, the Skunkboard runs all software on 16-bits, 5 clocks.)

The program will then generate a checksum, patch the header, and encrypt the boot. It will report 'JagCD compatible' just because the very first version of this program would crash if the cartridge was put into the JagCD's slot.

If you selected 32-bit, it will also offer a swapped version of the ROMs for 16-bit EPROMS.

I haven't burned 32-bit ROMs so I'm not positive which one you'd used. Likewise I haven't tried 8-bit ROMs. I built this to make 16-bit carts for myself, and the other modes were in Atari's original tool. ;)

The original file is also copied to a backup.

For the tech lovers - a few new words are defined for the checksum in unencrypted cart space at 0x410. All values are 32-bit, big endian. This is all filled in automatically by the program, it's for people who want to hexedit it later.

0x410 - start address for checksum
0x414 - number of 32-bit words to checksum
0x418 - checkum value plus 0x03D0DEAD -- calculate your checksum then add this value to it. 