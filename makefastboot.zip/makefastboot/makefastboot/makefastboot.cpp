// makefastboot.cpp : Defines the entry point for the console application.
// write a fast jaguar boot sector to the beginning of a game 
// note: OVERWRITES the header, make sure there is one!
// The new header only loads one encrypted block and does
// not do the MD5 test. It will boot anything like TYPEAB,
// but in 1s instead of 5s. Code by Tursi harmlesslion.com
// with assistance from KSkunk.

#include "stdafx.h"
#include <windows.h>
#include <stdio.h>

int _tmain(int argc, _TCHAR* argv[])
{
	FILE *fp;

	unsigned char fastboot[0x84] = {
#if 1
	// newer version that works with JagCD (DSP) and normal (GPU)
0xFE, 0x58, 0x00, 0x94, 0xE7, 0x8D, 0xBA, 0xB9, 0x54, 0x15, 0x5D, 0x1C, 0x0A, 0x3B, 0x4B, 0x73, 
0xDD, 0xB5, 0x91, 0xD0, 0x3E, 0xF9, 0x0A, 0xC9, 0x63, 0x60, 0xCE, 0x46, 0x0C, 0x26, 0xC0, 0xBA, 
0x6C, 0x88, 0xD9, 0xED, 0xF1, 0xD2, 0xE6, 0x61, 0xF9, 0xF4, 0xC6, 0xDB, 0xAA, 0xB7, 0x2E, 0x69, 
0xA6, 0x28, 0xE6, 0xA3, 0x48, 0x3F, 0xEC, 0x10, 0x31, 0xF5, 0xC3, 0xD2, 0xE1, 0xC1, 0xB7, 0xA1, 
0x9A, 0x1D, 0xD8, 0x8E, 0xB3, 0xE4, 0x22, 0xFE, 0xBF, 0xC4, 0xF5, 0xCD, 0x0D, 0xB4, 0x03, 0x1A, 
0x9B, 0x7E, 0xDC, 0x8C, 0x5B, 0x46, 0x2F, 0x3A, 0xFF, 0x0D, 0x1A, 0x97, 0xCB, 0xAC, 0x17, 0xFC, 
0xD7, 0xDC, 0x68, 0xBD, 0x11, 0x52, 0x3C, 0x3F, 0x21, 0x22, 0x8F, 0xC3, 0xD6, 0x71, 0x2B, 0x81, 
0xB7, 0x43, 0x8F, 0xA1, 0x8F, 0xEF, 0xB0, 0x27, 0xB0, 0x93, 0x0A, 0x23, 0x0A, 0x4A, 0xBE, 0xA1, 
0xC8, 0x84, 0x0F, 0x09 

/* .gpu
 .org $00F035AC

 MOVEI #$00FFF000,R1		; AND mask for address
 MOVEI #$00000EEC,R2		; Offset to chip control register
 MOVEI #$03D0DEAD,R4		; magic value for proceeding

 MOVE PC,R0					; get the PC to determine DSP or GPU
 AND R1,R0					; Mask out the relevant bits
 STORE R4,(R0)				; write the code
 SUB R2,R0					; Get control register (G_CTRL or D_CTRL)
 MOVEQ #0,R3				; Clear R3 for code below

GAMEOVR:
 JR GAMEOVR 				; wait for it to take effect
 STORE R3,(R0)				; stop the GPU/DSP

; Need an offset of $48 - this data is overwritten by the encrypt tool
; with the MD5 sum.
 NOP
 NOP 
 MOVEI #$0,R0
 MOVEI #$0,R0
 MOVEI #$0,R0
 MOVEI #$0,R0
 MOVEI #$0,R0
 MOVEI #$0,R0

; JagCD entry point (same for now)

Main: 
 ; There is a relocation at $4A that we can't touch
 MOVEI #$0,R0				; dummy value

 ; real boot starts here 
 MOVEI #$00FFF000,R1		; AND mask for address

 MOVEI #$0,R0				; This movei is hacked by the encryption tool
 MOVEI #$0,R0				; This movei is hacked by the encryption tool

 MOVEI #$00000EEC,R2		; Offset to chip control register
 MOVEI #$03D0DEAD,R4		; magic value for proceeding

 MOVE PC,R0					; get the PC to determine DSP or GPU
 AND R1,R0					; Mask out the relevant bits
 STORE R4,(R0)				; write the code
 SUB R2,R0					; Get control register (G_CTRL or D_CTRL)
 MOVEQ #0,R3				; Clear R3 for code below

GAMEOVR2:
 JR GAMEOVR2				; wait for it to take effect
 STORE R3,(R0)				; stop the GPU/DSP
 
 END
// plus some junk bytes ;)
  */

#else
	// older version that's just normal GPU boot
	0xFF,0xAB,0xAC,0x0D,0x51,0xC6,0x08,0x86,0xA0,0x17,0xE9,0x7A,0x2C,0x7E,0x97,0x26,
	0xA5,0x9B,0xB7,0x82,0x8D,0x14,0x37,0x5B,0x6E,0x24,0xE5,0x69,0x8E,0x86,0x71,0xE2,
	0xA9,0xDD,0x90,0x05,0xDB,0xF9,0xB8,0x82,0x64,0x8E,0xCF,0x40,0xB0,0xA2,0x1A,0xAF,
	0x98,0x12,0x09,0x9E,0xDE,0x80,0x8A,0xEA,0x24,0x82,0x80,0x0D,0xF3,0xC7,0xF8,0xC1,
	0x1B,0x03

	// decrypts to:
  	// 00F035AC: MOVEI   $00F03566,R00    (9800)	; address to pass ROM check
	// 00F035B2: MOVEI   $03D0DEAD,R04    (9804)	; magic value to unlock 68k
	// 00F035B8: JUMP    (R00)            (D000)	; go do it!
	// 00F035BA: NOP                      (E400)	; delay slot
	// plus some junk bytes ;)

#endif
	};
	
	if (argc < 2) {
		printf("Pass the name of a Jaguar game with header to patch\n");
		printf("A fastboot header will be applied to it.\n");
		return 0;
	}

	fp=fopen(argv[1], "rb+");
	if (NULL == fp) {
		printf("Can't open file for modify: %s\n", argv[1]);
		return -1;
	}
	
	int firstbyte=fgetc(fp);
	if ((firstbyte != 0xf6) && (firstbyte != 0xff) && (firstbyte != 0xfe)) {
		printf("File does not seem to have a header on it - will not patch!\n");
		printf("If you mean it, change the first byte to 0xf6 or 0xfe or 0xff.\n");
		return -1;
	}
	fclose(fp);
	
	// make a backup - Win specific code here
	char szBackup[MAX_PATH];
	memset(szBackup, 0, MAX_PATH);
	strncpy(szBackup, argv[1], MAX_PATH-5);
	strcat(szBackup, ".BAK");
	CopyFile(argv[1], szBackup, FALSE);

	// now do the patch
	fp=fopen(argv[1], "rb+");
	if (NULL == fp) {
		printf("Can't open file for modify!: %s\n", argv[1]);
		return -1;
	}
	fwrite(fastboot, 1, 132, fp);
	fclose(fp);

	printf("JagCD compatible - Successfully patched %s\n", argv[1]);

	return 0;
}

