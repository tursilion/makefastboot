Replaces a TypeAB header on a Jaguar cartridge image with a faster booting one.
This will decrypt and start in about 1s instead of 5-6s. It does not do any
hashing or verification of the cart and so is universal.

You must already have a header on the cart, or this program will refuse to execute.

A backup will be made, however any old backup file is replaced without warning.

Code by Tursi, HarmlessLion.com, with help from KSkunk.
Would appreciate a mention in any release that uses this.

This new version is JagCD compatible. Older images were not!
